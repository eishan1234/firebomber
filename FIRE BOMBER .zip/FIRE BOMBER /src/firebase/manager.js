const axios = require('axios');
const logger = require('../utils/logger');

class FirebaseManager {
  constructor(databases) {
    this.databases = databases || [];
    this.connections = {};
    this.cache = {};
    this.initializeConnections();
  }

  initializeConnections() {
    for (const db of this.databases) {
      this.connections[db.id] = {
        url: db.url,
        authKey: db.authKey,
        online: false,
        lastCheck: null
      };
    }
  }

  async testDatabase(db) {
    try {
      const url = `${db.url}/.json?auth=${db.authKey}&shallow=true`;
      const response = await axios.get(url, { timeout: 5000 });
      return { online: response.status === 200, error: null };
    } catch (err) {
      return { online: false, error: err.message };
    }
  }

  async addDatabase(db) {
    this.databases.push(db);
    this.connections[db.id] = {
      url: db.url,
      authKey: db.authKey,
      online: false,
      lastCheck: null
    };
    await this.testConnection(db.id);
  }

  removeDatabase(dbId) {
    this.databases = this.databases.filter(db => db.id !== dbId);
    delete this.connections[dbId];
    delete this.cache[dbId];
  }

  async testConnection(dbId) {
    const db = this.databases.find(d => d.id === dbId);
    if (!db) return false;
    try {
      await axios.get(`${db.url}/.json?auth=${db.authKey}&shallow=true`, { timeout: 5000 });
      this.connections[dbId].online = true;
      this.connections[dbId].lastCheck = new Date();
      return true;
    } catch (err) {
      this.connections[dbId].online = false;
      logger.warn(`Database ${db.name} offline: ${err.message}`);
      return false;
    }
  }

  async getDevices(dbId) {
    const db = this.databases.find(d => d.id === dbId);
    if (!db) return {};

    try {
      const url = `${db.url}/clients.json?auth=${db.authKey}`;
      const response = await axios.get(url, { timeout: 10000 });
      this.connections[dbId].online = true;
      this.cache[dbId] = response.data || {};
      return this.cache[dbId];
    } catch (err) {
      this.connections[dbId].online = false;
      logger.error(`Failed to get devices from ${db.name}: ${err.message}`);
      return this.cache[dbId] || {};
    }
  }

  async getAllDevices() {
    const result = {};
    for (const db of this.databases) {
      if (this.connections[db.id]?.online !== false) {
        try {
          result[db.id] = await this.getDevices(db.id);
        } catch (err) {
          result[db.id] = {};
        }
      } else {
        result[db.id] = this.cache[db.id] || {};
      }
    }
    return result;
  }

  async sendSMS(dbId, deviceId, payload) {
    const db = this.databases.find(d => d.id === dbId);
    if (!db) throw new Error('Database not found');

    const url = `${db.url}/clients/${deviceId}/webhookEvent/sendSms.json?auth=${db.authKey}`;
    try {
      const response = await axios.patch(url, payload, { timeout: 15000 });
      return { success: true, status: response.status, data: response.data };
    } catch (err) {
      return { success: false, error: err.message, status: err.response?.status || 500 };
    }
  }
}

module.exports = FirebaseManager;